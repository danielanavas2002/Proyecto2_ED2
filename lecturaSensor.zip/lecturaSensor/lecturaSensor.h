#ifndef LECTURASENSOR_H
#define LECTURASENSOR_H
#include <Arduino.h>

// Devuelve una variable float de la distancia en cm
// Recibe como parámetros los pines del Trigger y Echo
float lectura(int tgr, int ec); 

#endif