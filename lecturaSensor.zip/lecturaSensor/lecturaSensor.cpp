#include <lecturaSensor.h>

float lectura(int tgr, int ec){
  digitalWrite(tgr, LOW); // Apagar el trigger 2 microsegundos
  delayMicroseconds(2);
  digitalWrite(tgr, HIGH); // Encender el trigger 10 microsegundos
  delayMicroseconds(10);
  digitalWrite(tgr, LOW); // Apagar nuevamente el trigger
  float tiempoE = pulseIn(ec, HIGH); // Tiempo en microsegundos que el echo esta en HIGH
  return (tiempoE/2)*0.0343; // Convertir este tiempo a una medida equivalente en centimetros
}